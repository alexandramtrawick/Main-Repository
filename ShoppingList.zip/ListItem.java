package com.aca;

public class ListItem {
    private String itemName;
    private int quantity = 1;


    public ListItem(String itemName, int quantity){
        this.itemName = itemName;
        this.quantity = quantity;
    }

    public String getItemName() {
        return itemName;
    }

    public void setItemName(String itemName) {
        this.itemName = itemName;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    public String toString(){
        return itemName + ", " + quantity;
    }

}
