package com.aca;

import java.util.*;

public class ShoppingList {

    public static void main(String[] args) {
        List<ListItem> items = new ArrayList<>();
        System.out.println("Welcome, user! Choose from the following options:\n");
        ShoppingList.run(items);
    }
    private static void run(List<ListItem> items) { // COMPLETE
        Scanner scan = new Scanner(System.in);
        System.out.println("\n-Add\n-Print\n-Sort\n-Find\n-Remove\n-Clear\n-Exit\n");
        String userChoice = scan.next();

        if (userChoice.equalsIgnoreCase("Add")) {
            addItems(items);
        } else if (userChoice.equalsIgnoreCase("Print")) {
            printItems(items);
        } else if (userChoice.equalsIgnoreCase("Sort")) {
            sortItems(items);
        }else if(userChoice.equalsIgnoreCase("Find")){
            findItems(items);
        }else if(userChoice.equalsIgnoreCase("Remove")){
            removeItems(items);
        }else if(userChoice.equalsIgnoreCase("Clear")){
            clearItems(items);
        }else if(userChoice.equalsIgnoreCase("Exit")){
            System.out.println("Goodbye!");
            System.exit(0);
        }else{
            System.out.println("Your statement is invalid, try again.");
            run(items);
        }
    }
    private static void findItems(List<ListItem> items) { // COMPLETE
        Scanner scan = new Scanner(System.in);
        System.out.println("What item would you like to find?");
        String find = scan.next();

        for(ListItem i : items){
            if(find.equals(i.getItemName())){ // checks if the new item is already in the list "items"
                System.out.println("Found it!");
                run(items);
            }
        }
        System.out.println("No such item!");
        run(items);
    }
    private static void addItems(List<ListItem> items) { // WORKS, COULD BE SHORTENED/REFINED
        Scanner scan = new Scanner(System.in);

        System.out.println("What would you like to add? Type 'DONE' when you are finished adding items.");
        String newItemName = scan.next();

        if (!(newItemName.equalsIgnoreCase("DONE"))) { //if "DONE", it will take you back to run
            System.out.println("How many " + newItemName + " would you like?");
            int itemsToAdd = scan.nextInt();

            if (itemsToAdd >= 1 && itemsToAdd <= 5) { //add # to items already on the list, must be 1-5
                for (ListItem i : items) {
                    if (newItemName.equals(i.getItemName())) { // checks if the new item is already in the list "items"
                        int currentQuantity = i.getQuantity();
                        int newTotal = currentQuantity + itemsToAdd;

                        if (newTotal > 5) { //if user wants to list more than 5 of an item
                            i.setQuantity(5);
                            System.out.println("Can only list a maximum of 5 for each object. Your list has been updated to contain 5 " + newItemName);
                            addItems(items);
                        }

                        i.setQuantity(newTotal);
                        System.out.println("You have added " + itemsToAdd + " " + newItemName + ". You now have " + i.getQuantity() + " " + newItemName);
                        addItems(items);
                    }
                }

                ListItem item = new ListItem(newItemName, itemsToAdd);
                items.add(item);
                System.out.println("You have added " + item + ". ");
                addItems(items);
            } else {
                System.out.println("Invalid number. You can get 1-5 of each object.");
                addItems(items);
            }
        } else {
            run(items);
        }
    }
    private static void printItems(List<ListItem> items) { // COMPLETE
        int count = 1;
        for(ListItem i : items){
          System.out.println(count + ". " + i);
          count++;
        }
        run(items);
    }

    private static void sortItems(List<ListItem> items) { // COMPLETE
        items.sort(Comparator.comparing(ListItem::getItemName));
        items.forEach(System.out::println);
        //prints out sorted list
        run(items);
    }
    private static void removeItems(List<ListItem> items) { // COMPLETE
        Scanner scan = new Scanner(System.in);

        System.out.println("What would you like to remove?");
        String itemToAdd = scan.next();

        for (ListItem i : items) {
            if (itemToAdd.equals(i.getItemName())) {
                int quantity = i.getQuantity();
                System.out.println("How many would you like to remove? There are currently " + quantity + " " + itemToAdd + ".");
                int toRemove = scan.nextInt();


                if (toRemove < 0 || toRemove > quantity) {
                    System.out.println("You cannot remove that amount. Try again.");
                    removeItems(items);
                }
                quantity = quantity - toRemove;
                if (quantity <= 0) {
                    items.remove(i);
                    System.out.println(itemToAdd + " has/have been completely cleared from the list.");
                    run(items);
                } else {
                    i.setQuantity(quantity);
                    System.out.println("There are now " + quantity + " " + itemToAdd + " on the list.");
                    run(items);
                }
            }
            System.out.print("That is not a valid item number. Try again.");
            run(items);
        }
    }
    private static void clearItems(List<ListItem> items) { // COMPLETE

        items.clear();
        System.out.println("The list has been cleared.");
        int count = 1;

        for(ListItem i : items){
            System.out.println(count + ". " + i);
            count++;
        }
        run(items);
    }
}